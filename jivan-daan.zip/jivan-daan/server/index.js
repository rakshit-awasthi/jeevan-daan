import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import axios from "axios";

dotenv.config();

const app = express();   // IMPORTANT LINE

app.use(cors());
app.use(express.json());



// test route
app.get("/", (req,res)=>{
res.send("AI server running ✅");
});



// chat route
app.post("/chat", async (req,res)=>{

try{

const message = req.body.message;

console.log("User message:",message);



/* temporary test reply */

res.json({

reply: "AI connected successfully 🎉"

});


}catch(error){

console.log(error);

res.json({

reply:"error"

});

}

});



app.listen(5000,()=>{

console.log("Server running on http://127.0.0.1:5000/chat");

});