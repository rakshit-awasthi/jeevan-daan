import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";


const firebaseConfig = {
  apiKey: "AIzaSyCvQZZWCpljbLc0YFN5xcYqrAUFWJjNYNI",
  authDomain: "jivan-dan-d1606.firebaseapp.com",
  projectId: "jivan-dan-d1606",
  storageBucket: "jivan-dan-d1606.firebasestorage.app",
  messagingSenderId: "484426837692",
  appId: "1:484426837692:web:1e9dd6efeb4c67c65b2ab9",
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);


export const storage = getStorage(app);