import { db } from "./firebase";
import {
collection,
addDoc,
getDocs,
query,
where
} from "firebase/firestore";



// search answer
export async function getLearnedAnswer(text){

const q=query(
collection(db,"ai_training"),
where("question","==",text.toLowerCase())
);

const snap = await getDocs(q);

if(!snap.empty){

return snap.docs[0].data().answer;

}

return null;

}



// save new question
export async function saveQuestion(text){

await addDoc(
collection(db,"ai_training"),
{
question:text.toLowerCase(),
answer:"pending"
}
);

}