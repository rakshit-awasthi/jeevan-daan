import Navbar from "../components/common/Navbar";
import Footer from "../components/common/Footer";
import CursorGlow from "../components/ui/CursorGlow";
import FloatingElements from "../components/ui/FloatingElements";
import AIChatbot from "../components/chatbot/Chatbot";

import { motion } from "framer-motion";
import { Link } from "react-router-dom";

export default function Home(){

const bloodGroups=["A+","A-","B+","B-","O+","O-","AB+","AB-"];

return(

<div className="relative min-h-screen text-white overflow-hidden bg-[#040006]">

<Navbar/>
<CursorGlow/>
<FloatingElements/>


{/* BACKGROUND */}

<div className="absolute inset-0 -z-20 overflow-hidden">

<div className="absolute inset-0 bg-gradient-to-br from-[#140000] via-[#050008] to-black"/>

<div className="absolute top-[-200px] left-[-200px] w-[700px] h-[700px] bg-red-700 opacity-40 blur-[200px] rounded-full"/>

<div className="absolute bottom-[-200px] right-[-200px] w-[700px] h-[700px] bg-rose-800 opacity-40 blur-[200px] rounded-full"/>


{/* ECG */}

<svg className="absolute w-[300%] h-full opacity-30" viewBox="0 0 1200 200">

<path d="M0 100 L80 100 L110 60 L140 140 L170 100 L300 100 L330 60 L360 140 L390 100 L1200 100"
stroke="#ff2a4f" strokeWidth="2" fill="none">

<animateTransform attributeName="transform" type="translate"
from="0 0" to="-400 0" dur="6s" repeatCount="indefinite"/>

</path>

</svg>

</div>



{/* HERO */}

<section className="max-w-7xl mx-auto px-6 pt-32 pb-28 grid md:grid-cols-2 gap-12 items-center">

<div>

<motion.h1

initial={{opacity:0,y:40}}

animate={{opacity:1,y:0}}

transition={{duration:0.6}}

className="text-4xl md:text-6xl font-bold leading-tight">

Donate Blood

<span className="block text-red-500 mt-2">

Save Lives

</span>

</motion.h1>


<p className="mt-6 text-gray-400">

Instantly find blood donors and help people in emergency situations.

</p>


<div className="flex gap-4 mt-8 flex-wrap">

<Link to="/find"
className="bg-red-600 px-6 py-3 rounded-lg">

Find Donor

</Link>

<Link to="/request"
className="border border-red-500 px-6 py-3 rounded-lg">

Request Blood

</Link>

</div>

</div>



<motion.img

src="https://cdn-icons-png.flaticon.com/512/2966/2966483.png"

className="w-full max-w-md mx-auto"

animate={{y:[0,-20,0]}}

transition={{duration:4,repeat:Infinity}}

/>

</section>



{/* STATS */}

<section className="max-w-6xl mx-auto px-6 grid md:grid-cols-3 gap-6 pb-28">

{["1200+ Donors","350+ Lives Saved","80+ Hospitals"].map((s,i)=>(

<div key={i}

className="bg-white/5 border border-red-500/20 p-8 rounded-xl text-center backdrop-blur-xl">

{s}

</div>

))}

</section>



{/* HOW IT WORKS */}

<section className="max-w-7xl mx-auto px-6 pb-32">

<h2 className="text-4xl font-bold text-center mb-16">

How it works

</h2>


<div className="grid md:grid-cols-3 gap-8">

{[
"Search blood group",
"Connect donor instantly",
"Save life"
].map((item,i)=>(

<motion.div

key={i}

whileHover={{scale:1.05}}

className="bg-white/5 border border-red-500/20 p-8 rounded-xl text-center backdrop-blur-xl">

<div className="text-red-500 text-3xl mb-4">

{i+1}

</div>

{item}

</motion.div>

))}

</div>

</section>



{/* INFO */}

<section className="max-w-7xl mx-auto px-6 pb-32 grid md:grid-cols-2 gap-12 items-center">

<motion.img

src="https://cdn-icons-png.flaticon.com/512/387/387561.png"

className="w-full max-w-md"

animate={{y:[0,-25,0]}}

transition={{duration:5,repeat:Infinity}}

/>


<div>

<h2 className="text-4xl font-bold">

Why donate blood?

</h2>

<p className="text-gray-400 mt-4">

One blood donation can save multiple lives and help hospitals.

</p>

</div>

</section>



{/* BLOOD GROUP */}

<section className="max-w-5xl mx-auto px-6 pb-32 text-center">

<h2 className="text-4xl font-bold mb-10">

Available Blood Groups

</h2>


<div className="grid grid-cols-4 md:grid-cols-8 gap-4">

{bloodGroups.map(g=>(

<motion.div

whileHover={{scale:1.1}}

key={g}

className="bg-red-600/20 border border-red-500 p-4 rounded-lg">

{g}

</motion.div>

))}

</div>

</section>



{/* VIDEO */}

<section className="relative max-w-6xl mx-auto px-6 py-32 text-center">

<h2 className="text-4xl font-bold mb-16">

Blood Donation Awareness

</h2>



<div className="relative mx-auto w-full max-w-md">

<div className="absolute inset-0 bg-red-600/20 blur-3xl rounded-full scale-110"/>


<motion.img

src="https://cdn-icons-png.flaticon.com/512/809/809957.png"

className="absolute w-10 -left-10 top-20 opacity-70"

animate={{y:[0,-20,0]}}

transition={{duration:3,repeat:Infinity}}

/>


<motion.img

src="https://cdn-icons-png.flaticon.com/512/809/809957.png"

className="absolute w-12 -right-10 top-40 opacity-60"

animate={{y:[0,-25,0]}}

transition={{duration:4,repeat:Infinity}}

/>


<motion.div

whileHover={{scale:1.03}}

className="relative backdrop-blur-xl bg-white/5 border border-red-500/20 rounded-2xl overflow-hidden shadow-xl">

<iframe

className="w-full aspect-[9/16]"

src="https://www.youtube.com/embed/MVcX-lbbkso"

title="Blood Donation"

allowFullScreen

/>

</motion.div>

</div>

</section>



{/* CTA */}

<section className="max-w-5xl mx-auto text-center pb-32">

<h2 className="text-4xl font-bold">

Become donor today

</h2>

<p className="text-gray-400 mt-4">

Your one step can save many lives.

</p>

<Link to="/become-donor"

className="inline-block mt-8 bg-red-600 px-10 py-3 rounded-lg">

Register Now

</Link>

</section>



{/* FAQ */}

<section className="max-w-4xl mx-auto px-6 pb-32">

<h2 className="text-4xl font-bold text-center mb-10">

FAQ

</h2>


{[
"Is blood donation safe?",
"How fast donor responds?",
"Can anyone donate blood?"
].map((q,i)=>(

<div key={i}

className="bg-white/5 border border-red-500/20 p-6 rounded-xl mb-4">

{q}

</div>

))}

</section>
<AIChatbot/>



<Footer/>

</div>

)

}