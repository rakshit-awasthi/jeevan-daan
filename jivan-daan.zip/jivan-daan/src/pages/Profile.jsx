import Navbar from "../components/common/Navbar";
import Footer from "../components/common/Footer";

import { motion } from "framer-motion";

import { useEffect, useState } from "react";

import { auth, db } from "../services/firebase";

import { doc, getDoc, setDoc } from "firebase/firestore";

import { onAuthStateChanged } from "firebase/auth";

import { uploadImage } from "../services/cloudinary";

export default function Profile(){

const [loading,setLoading] = useState(true);

const [editMode,setEditMode] = useState(false);

const [file,setFile] = useState(null);

const [imagePreview,setImagePreview] = useState("");

const [userData,setUserData] = useState({

name:"",
email:"",
bloodGroup:"",
location:"",
phone:"",
age:"",
image:""

});


/* load user */

useEffect(()=>{

const unsubscribe = onAuthStateChanged(auth, async(user)=>{

if(!user){

setLoading(false);
return;

}

try{

const ref = doc(db,"users",user.uid);

const snap = await getDoc(ref);

if(snap.exists()){

const data = snap.data();

setUserData({

name:data.name || "",

email:data.email || user.email,

bloodGroup:data.bloodGroup || "",

location:data.location || "",

phone:data.phone || "",

age:data.age || "",

image:data.image || ""

});

setImagePreview(data.image || "");

}

else{

setUserData(prev=>({

...prev,

email:user.email

}));

}

}
catch(err){

console.log("load error",err);

}

setLoading(false);

});

return ()=>unsubscribe();

},[]);



/* input change */

function handleChange(e){

setUserData({

...userData,

[e.target.name]:e.target.value

});

}



/* image */

function handleFile(e){

const selected = e.target.files[0];

setFile(selected);

if(selected){

setImagePreview(URL.createObjectURL(selected));

}

}



/* save */

async function save(){

console.log("save clicked");

try{

const user = auth.currentUser;

if(!user){

alert("login required");

return;

}

let imageUrl = imagePreview;


/* upload image */

if(file){

try{

imageUrl = await uploadImage(file);

}
catch(err){

console.log("image error",err);

alert("image upload error");

}

}


/* save firestore */

await setDoc(

doc(db,"users",user.uid),

{

name:userData.name || "",

phone:userData.phone || "",

age:userData.age || "",

location:userData.location || "",

bloodGroup:userData.bloodGroup || "",

image:imageUrl || "",

email:user.email,

updatedAt:new Date()

},

{merge:true}

);

setEditMode(false);

alert("Profile Saved ✅");

}
catch(err){

console.log("save error",err);

alert("save error");

}

}



if(loading){

return(

<div className="min-h-screen bg-black flex items-center justify-center text-white">

Loading profile...

</div>

);

}



return(

<div className="min-h-screen bg-[#050008] text-white">

<Navbar/>


{/* header */}

<div className="max-w-6xl mx-auto px-6 pt-32 pb-16">

<motion.div

initial={{opacity:0,y:40}}

animate={{opacity:1,y:0}}

className="bg-white/5 border border-red-500/20 backdrop-blur-xl rounded-2xl p-8"

>

<div className="flex flex-col md:flex-row items-center gap-6">


{/* image */}

<div className="flex flex-col items-center">

<img

src={

imagePreview ||

"https://cdn-icons-png.flaticon.com/512/3135/3135715.png"

}

className="w-28 h-28 rounded-full border-4 border-red-500 object-cover"

/>


{editMode &&(

<input

type="file"

onChange={handleFile}

className="mt-2 text-sm"

/>

)}

</div>



<div className="flex-1">


{/* name */}

{editMode ?(

<input

name="name"

value={userData.name}

onChange={handleChange}

placeholder="Full Name"

className="bg-black/40 border border-white/10 p-2 rounded-lg w-full"

/>

):(

<h1 className="text-3xl font-bold">

{userData.name || "User"}

</h1>

)}



<p className="text-gray-400">

{userData.email}

</p>



{/* blood group */}

{editMode ?(

<select

name="bloodGroup"

value={userData.bloodGroup}

onChange={handleChange}

className="mt-3 bg-black/40 border border-white/10 p-2 rounded-lg"

>

<option value="">Blood Group</option>

<option>A+</option>
<option>A-</option>
<option>B+</option>
<option>B-</option>
<option>AB+</option>
<option>AB-</option>
<option>O+</option>
<option>O-</option>

</select>

):(

<div className="mt-3 inline-block bg-red-600 px-4 py-1 rounded-full">

{userData.bloodGroup || "Blood not set"}

</div>

)}

</div>



{/* button */}

<button

onClick={editMode ? save : ()=>setEditMode(true)}

className="bg-red-600 px-5 py-2 rounded-lg hover:bg-red-700"

>

{editMode ? "Save" : "Edit Profile"}

</button>


</div>

</motion.div>

</div>



{/* personal info */}

<div className="max-w-6xl mx-auto px-6 pb-32">

<div className="bg-white/5 border border-red-500/20 rounded-xl p-8 grid md:grid-cols-2 gap-6">


{/* phone */}

<div>

<p className="text-gray-400">

Phone

</p>

{editMode ?(

<input

name="phone"

value={userData.phone}

onChange={handleChange}

placeholder="Phone"

className="bg-black/40 border border-white/10 p-2 rounded-lg w-full"

/>

):(

<p>{userData.phone || "not set"}</p>

)}

</div>



{/* age */}

<div>

<p className="text-gray-400">

Age

</p>

{editMode ?(

<input

name="age"

value={userData.age}

onChange={handleChange}

placeholder="Age"

className="bg-black/40 border border-white/10 p-2 rounded-lg w-full"

/>

):(

<p>{userData.age || "not set"}</p>

)}

</div>



{/* city */}

<div>

<p className="text-gray-400">

City

</p>

{editMode ?(

<input

name="location"

value={userData.location}

onChange={handleChange}

placeholder="City"

className="bg-black/40 border border-white/10 p-2 rounded-lg w-full"

/>

):(

<p>{userData.location || "not set"}</p>

)}

</div>


</div>

</div>



<Footer/>

</div>

);

}