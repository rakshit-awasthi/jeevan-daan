import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { db } from "../services/firebase";
import { doc, getDoc } from "firebase/firestore";
import Navbar from "../components/common/Navbar";
import { motion } from "framer-motion";

export default function DonorProfile(){

const { id } = useParams();

const [donor,setDonor] = useState(null);

useEffect(()=>{

async function fetchDonor(){

const snap = await getDoc(doc(db,"users",id));

if(snap.exists()){

setDonor(snap.data());

}

}

fetchDonor();

},[id]);


if(!donor){

return(
<div className="text-white text-center mt-20">

Loading...

</div>
);
}


return(

<div className="min-h-screen bg-[#020617] text-white">

<Navbar/>

<div className="pt-28 flex justify-center">

<motion.div

initial={{opacity:0,y:40}}

animate={{opacity:1,y:0}}

className="bg-white/5 border border-white/10 p-8 rounded-2xl text-center w-80"

>

<img

src={donor.image || "/avatar.png"}

className="w-32 h-32 rounded-full object-cover mx-auto mb-4 border border-white/20"

/>

<h1 className="text-2xl font-bold">

{donor.name}

</h1>


<p className="text-red-400 text-lg mt-2">

{donor.bloodGroup}

</p>


<p className="mt-2">

📍 {donor.location}

</p>


<p className="mt-2">

📞 {donor.phone}

</p>


<a

href={`tel:${donor.phone}`}

className="block mt-6 p-3 bg-green-500 rounded-xl"

>

Call Donor

</a>


</motion.div>

</div>

</div>

);

}