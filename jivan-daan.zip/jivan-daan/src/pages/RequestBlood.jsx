import { useState } from "react";
import Navbar from "../components/common/Navbar";
import { db } from "../services/firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { motion } from "framer-motion";

export default function RequestBlood(){

const [form,setForm] = useState({
patientName:"",
bloodGroup:"",
units:"",
hospital:"",
city:"",
contact:"",
urgency:"Normal"
});

const [loading,setLoading] = useState(false);
const [success,setSuccess] = useState(false);

function handleChange(e){
setForm({
...form,
[e.target.name]:e.target.value
});
}

async function handleSubmit(e){
e.preventDefault();

if(!form.patientName || !form.bloodGroup || !form.units || !form.hospital || !form.contact){
alert("Please fill all required fields");
return;
}

try{
setLoading(true);

await addDoc(collection(db,"bloodRequests"),{
...form,
createdAt:serverTimestamp()
});

setSuccess(true);

setForm({
patientName:"",
bloodGroup:"",
units:"",
hospital:"",
city:"",
contact:"",
urgency:"Normal"
});

}
catch(err){
console.log(err);
alert("Error submitting request");
}

setLoading(false);
}

return(
<>
<Navbar/>

<div className="min-h-screen bg-gradient-to-br from-red-900 via-black to-red-950 flex items-center justify-center px-4">

<motion.div
initial={{opacity:0, y:40}}
animate={{opacity:1, y:0}}
transition={{duration:0.6}}
className="w-full max-w-2xl bg-white/10 backdrop-blur-lg border border-red-500/20 rounded-2xl shadow-xl p-8"
>

<h2 className="text-3xl font-bold text-white mb-6 text-center">
Request Blood 🩸
</h2>

<form onSubmit={handleSubmit} className="space-y-4">

<input
name="patientName"
placeholder="Patient Name"
value={form.patientName}
onChange={handleChange}
className="w-full p-3 rounded-lg bg-black/30 text-white border border-red-400/20 focus:outline-none"
/>

<select
name="bloodGroup"
value={form.bloodGroup}
onChange={handleChange}
className="w-full p-3 rounded-lg bg-black/30 text-white border border-red-400/20"
>

<option value="">Select Blood Group</option>
<option>A+</option>
<option>A-</option>
<option>B+</option>
<option>B-</option>
<option>O+</option>
<option>O-</option>
<option>AB+</option>
<option>AB-</option>

</select>

<input
name="units"
placeholder="Units Required"
value={form.units}
onChange={handleChange}
type="number"
className="w-full p-3 rounded-lg bg-black/30 text-white border border-red-400/20"
/>

<input
name="hospital"
placeholder="Hospital Name"
value={form.hospital}
onChange={handleChange}
className="w-full p-3 rounded-lg bg-black/30 text-white border border-red-400/20"
/>

<input
name="city"
placeholder="City"
value={form.city}
onChange={handleChange}
className="w-full p-3 rounded-lg bg-black/30 text-white border border-red-400/20"
/>

<input
name="contact"
placeholder="Contact Number"
value={form.contact}
onChange={handleChange}
className="w-full p-3 rounded-lg bg-black/30 text-white border border-red-400/20"
/>

<select
name="urgency"
value={form.urgency}
onChange={handleChange}
className="w-full p-3 rounded-lg bg-black/30 text-white border border-red-400/20"
>

<option>Normal</option>
<option>Urgent</option>
<option>Emergency</option>

</select>

<motion.button
whileTap={{scale:0.95}}
whileHover={{scale:1.02}}
className="w-full p-3 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold shadow-lg"
>

{loading ? "Submitting..." : "Submit Request"}

</motion.button>

{success && (
<p className="text-green-400 text-center">
Request submitted successfully ✔
</p>
)}

</form>

</motion.div>

</div>

</>
);
}