import { useEffect, useState } from "react";
import { db, auth, storage } from "../services/firebase";
import { doc, setDoc, getDoc } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import Navbar from "../components/common/Navbar";
import { motion } from "framer-motion";

export default function BecomeDonor(){

const [form,setForm]=useState({

name:"",
bloodGroup:"",
location:"",
phone:"",
image:""

});

const [file,setFile]=useState(null);
const [preview,setPreview]=useState("");

const [loading,setLoading]=useState(false);
const [alreadyDonor,setAlreadyDonor]=useState(false);


useEffect(()=>{

async function checkDonor(){

const user = auth.currentUser;

if(!user) return;

const refDoc = doc(db,"users",user.uid);

const snap = await getDoc(refDoc);

if(snap.exists()){

setAlreadyDonor(true);

setForm(snap.data());

setPreview(snap.data().image);

}

}

checkDonor();

},[]);



function handleChange(e){

setForm({

...form,
[e.target.name]:e.target.value

});

}



function handleImage(e){

const selected = e.target.files[0];

if(!selected) return;

setFile(selected);

setPreview(URL.createObjectURL(selected));

}



async function handleSubmit(e){

e.preventDefault();

const user = auth.currentUser;

if(!user) return alert("login required");

setLoading(true);

let imageUrl = form.image;

try{

if(file){

const storageRef = ref(storage,`donors/${user.uid}`);

await uploadBytes(storageRef,file);

imageUrl = await getDownloadURL(storageRef);

}

await setDoc(doc(db,"users",user.uid),{

...form,
image:imageUrl,
uid:user.uid,
email:user.email

});

setAlreadyDonor(true);

}
catch(err){

console.log(err);

alert("error uploading");

}

setLoading(false);

}



return(

<div className="min-h-screen bg-[#020617] text-white">

<Navbar/>

<div className="pt-28 flex justify-center px-4">

<motion.form

onSubmit={handleSubmit}

initial={{opacity:0,y:30}}

animate={{opacity:1,y:0}}

className="w-full max-w-lg bg-white/5 border border-white/10 backdrop-blur-xl p-8 rounded-2xl"

>

<h1 className="text-3xl font-bold mb-6 text-center bg-gradient-to-r from-red-500 to-blue-500 bg-clip-text text-transparent">

Become a Donor

</h1>


{alreadyDonor && (

<p className="text-green-400 mb-4 text-center">

You are already registered as donor ✅

</p>

)}


<input
type="text"
name="name"
placeholder="Full Name"
value={form.name}
onChange={handleChange}
disabled={alreadyDonor}
required
className="w-full mb-4 p-3 rounded-xl bg-black/40 border border-white/10"
/>


<select
name="bloodGroup"
value={form.bloodGroup}
onChange={handleChange}
disabled={alreadyDonor}
required
className="w-full mb-4 p-3 rounded-xl bg-black/40 border border-white/10"
>

<option value="">Select Blood Group</option>

<option>A+</option>
<option>A-</option>
<option>B+</option>
<option>B-</option>
<option>O+</option>
<option>O-</option>
<option>AB+</option>
<option>AB-</option>

</select>



<input
type="text"
name="location"
placeholder="City"
value={form.location}
onChange={handleChange}
disabled={alreadyDonor}
required
className="w-full mb-4 p-3 rounded-xl bg-black/40 border border-white/10"
/>



<input
type="text"
name="phone"
placeholder="Phone"
value={form.phone}
onChange={handleChange}
disabled={alreadyDonor}
required
className="w-full mb-4 p-3 rounded-xl bg-black/40 border border-white/10"
/>


{/* IMAGE UPLOAD */}

<label className="block mb-2 text-sm text-gray-300">

Upload Profile Image

</label>

<input
type="file"
accept="image/*"
onChange={handleImage}
disabled={alreadyDonor}
className="w-full mb-4"
/>


{/* preview */}

{preview && (

<img

src={preview}

alt="preview"

className="w-32 h-32 object-cover rounded-full mb-6 border border-white/20"

/>

)}


<button

disabled={loading || alreadyDonor}

className="w-full p-3 rounded-xl bg-gradient-to-r from-red-500 to-blue-500"

>

{alreadyDonor ? "Already Registered" : loading ? "Saving..." : "Register"}

</button>


</motion.form>

</div>

</div>

);

}