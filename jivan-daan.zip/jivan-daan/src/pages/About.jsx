import Navbar from "../components/common/Navbar";
import { motion } from "framer-motion";

export default function About(){

return(
<>
<Navbar/>

<div className="min-h-screen bg-gradient-to-br from-red-900 via-black to-red-950 text-white flex items-center justify-center px-6">

<motion.div
initial={{opacity:0, y:40}}
animate={{opacity:1, y:0}}
transition={{duration:0.6}}
className="max-w-4xl bg-white/10 backdrop-blur-lg border border-red-500/20 rounded-2xl shadow-xl p-8"
>

<h1 className="text-4xl font-bold mb-6 text-center">
About Blood Donation 🩸
</h1>

<p className="text-gray-300 leading-relaxed mb-6">

Our platform helps people find blood donors quickly in emergency situations.
Many patients lose their lives because blood is not available at the right time.
Our mission is to connect donors and patients easily using technology.

</p>

<div className="grid md:grid-cols-3 gap-6">

<motion.div
whileHover={{scale:1.05}}
className="bg-black/40 p-6 rounded-xl border border-red-400/20"
>

<h3 className="text-xl font-semibold mb-2">
Fast Search ⚡
</h3>

<p className="text-gray-400 text-sm">
Find blood donors quickly by blood group and location.
</p>

</motion.div>

<motion.div
whileHover={{scale:1.05}}
className="bg-black/40 p-6 rounded-xl border border-red-400/20"
>

<h3 className="text-xl font-semibold mb-2">
Emergency Help 🚑
</h3>

<p className="text-gray-400 text-sm">
Patients can request blood anytime for urgent medical needs.
</p>

</motion.div>

<motion.div
whileHover={{scale:1.05}}
className="bg-black/40 p-6 rounded-xl border border-red-400/20"
>

<h3 className="text-xl font-semibold mb-2">
Save Lives ❤️
</h3>

<p className="text-gray-400 text-sm">
Every donation can save multiple lives and help families in need.
</p>

</motion.div>

</div>

<div className="mt-8 text-center">

<p className="text-gray-400">
Together we can make blood available for everyone.
</p>

</div>

</motion.div>

</div>

</>
);
}