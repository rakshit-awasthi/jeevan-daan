import { signInWithPopup, GoogleAuthProvider } from "firebase/auth";
import { auth } from "../services/firebase";

import { doc, setDoc, getDoc } from "firebase/firestore";
import { db } from "../services/firebase";

import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { useState } from "react";

export default function Auth(){

const navigate = useNavigate();

const [loading,setLoading] = useState(false);
const [isRegister,setIsRegister] = useState(false);

const [form,setForm] = useState({

name:"",
phone:"",
bloodGroup:""

});

const handleChange = (e)=>{

setForm({

...form,
[e.target.name]:e.target.value

});

};

const loginWithGoogle = async ()=>{

const provider = new GoogleAuthProvider();

try{

setLoading(true);

const result = await signInWithPopup(auth,provider);

const user = result.user;

const userRef = doc(db,"users",user.uid);

const userSnap = await getDoc(userRef);

if(!userSnap.exists()){

setIsRegister(true);

}else{

navigate("/");

}

}catch(err){

console.log(err);

}finally{

setLoading(false);

}

};

const registerUser = async ()=>{

try{

setLoading(true);

const user = auth.currentUser;

await setDoc(

doc(db,"users",user.uid),

{

name:form.name,
phone:form.phone,
bloodGroup:form.bloodGroup,
email:user.email,
createdAt:new Date()

}

);

navigate("/");

}catch(err){

console.log(err);

}finally{

setLoading(false);

}

};

return(

<div className="relative min-h-screen flex items-center justify-center bg-black overflow-hidden text-white">

{/* grid */}

<div

className="absolute inset-0 opacity-[0.05]"

style={{

backgroundImage:

"linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg,#fff 1px, transparent 1px)",

backgroundSize:"70px 70px"

}}

/>

{/* glow */}

<motion.div
animate={{ x:[0,60,-60,0], y:[0,-40,40,0] }}
transition={{ duration:18, repeat:Infinity }}
className="absolute w-[500px] h-[500px] bg-red-600 opacity-30 blur-[140px] rounded-full"
/>

<motion.div
animate={{ x:[0,-70,70,0], y:[0,60,-60,0] }}
transition={{ duration:20, repeat:Infinity }}
className="absolute w-[500px] h-[500px] bg-purple-600 opacity-30 blur-[140px] rounded-full"
/>

{/* ECG 1 */}

<svg className="absolute top-[18%] w-full opacity-20" height="120">

<motion.path

d="M0 60 L80 60 L100 35 L120 85 L140 30 L160 60 L260 60 L280 40 L300 80 L320 30 L340 60 L1000 60"

stroke="url(#g1)"
strokeWidth="2"
fill="transparent"

initial={{ pathLength:0 }}

animate={{ pathLength:1 }}

transition={{ duration:3, repeat:Infinity }}

 />

<motion.circle

r="4"

fill="#ff4d6d"

animate={{ cx:[0,1000] }}

transition={{ duration:3, repeat:Infinity }}

/>

<defs>

<linearGradient id="g1">

<stop offset="0%" stopColor="#ef4444"/>
<stop offset="100%" stopColor="#6366f1"/>

</linearGradient>

</defs>

</svg>

{/* ECG 2 */}

<svg className="absolute bottom-[30%] w-full opacity-30" height="120">

<motion.path

d="M0 60 L100 60 L120 40 L140 80 L160 30 L180 60 L280 60 L300 40 L320 80 L340 30 L360 60 L1000 60"

stroke="url(#g2)"
strokeWidth="3"
fill="transparent"

initial={{ pathLength:0 }}

animate={{ pathLength:1 }}

transition={{ duration:2.5, repeat:Infinity }}

/>

<motion.circle

r="5"

fill="#fb7185"

animate={{ cx:[0,1000] }}

transition={{ duration:2.5, repeat:Infinity }}

/>

<defs>

<linearGradient id="g2">

<stop offset="0%" stopColor="#f43f5e"/>
<stop offset="100%" stopColor="#8b5cf6"/>

</linearGradient>

</defs>

</svg>

{/* ECG 3 */}

<svg className="absolute bottom-[12%] w-full opacity-40" height="120">

<motion.path

d="M0 60 L80 60 L100 35 L120 85 L140 30 L160 60 L260 60 L280 40 L300 80 L320 30 L340 60 L440 60 L460 35 L480 85 L500 30 L520 60 L1000 60"

stroke="url(#g3)"
strokeWidth="3"
fill="transparent"

initial={{ pathLength:0 }}

animate={{ pathLength:1 }}

transition={{ duration:2.2, repeat:Infinity }}

/>

<motion.circle

r="5"

fill="#f43f5e"

animate={{ cx:[0,1000] }}

transition={{ duration:2.2, repeat:Infinity }}

/>

<defs>

<linearGradient id="g3">

<stop offset="0%" stopColor="#ef4444"/>
<stop offset="50%" stopColor="#ec4899"/>
<stop offset="100%" stopColor="#8b5cf6"/>

</linearGradient>

</defs>

</svg>

{/* card */}

<motion.div

initial={{ opacity:0, y:80 }}
animate={{ opacity:1, y:0 }}

className="relative z-10 w-[420px] p-10 rounded-3xl backdrop-blur-2xl bg-white/10 border border-white/20 shadow-[0_0_80px_rgba(255,0,80,0.35)]"

>

<h1 className="text-4xl font-bold text-center mb-3 bg-gradient-to-r from-red-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">

JIVAN DAAN

</h1>

<p className="text-gray-300 text-center mb-6">

AI Powered Blood Donation Platform

</p>

{

!isRegister ? (

<>

<motion.button

whileHover={{ scale:1.05 }}
whileTap={{ scale:0.95 }}

onClick={loginWithGoogle}

disabled={loading}

className="w-full py-3 mb-4 rounded-xl font-semibold bg-gradient-to-r from-red-500 via-pink-500 to-purple-500 shadow-lg"

>

{loading ? "Checking..." : "Continue with Google"}

</motion.button>

<p className="text-xs text-gray-400 text-center">

New users complete registration first

</p>

</>

) : (

<>

<input

placeholder="Full Name"

name="name"

onChange={handleChange}

className="w-full mb-3 p-3 rounded-lg bg-white/10 border border-white/20 outline-none"

/>

<input

placeholder="Phone Number"

name="phone"

onChange={handleChange}

className="w-full mb-3 p-3 rounded-lg bg-white/10 border border-white/20 outline-none"

/>

<select

name="bloodGroup"

onChange={handleChange}

className="w-full mb-4 p-3 rounded-lg bg-black/40 border border-white/20"

>

<option>Blood Group</option>

<option>A+</option>
<option>A-</option>
<option>B+</option>
<option>B-</option>
<option>O+</option>
<option>O-</option>
<option>AB+</option>
<option>AB-</option>

</select>

<motion.button

whileHover={{ scale:1.05 }}
whileTap={{ scale:0.95 }}

onClick={registerUser}

disabled={loading}

className="w-full py-3 rounded-xl font-semibold bg-gradient-to-r from-green-500 to-emerald-600 shadow-lg"

>

{loading ? "Saving..." : "Complete Registration"}

</motion.button>

</>

)

}

<p className="text-gray-500 text-xs text-center mt-6">

Secure Firebase Authentication

</p>

</motion.div>

{/* particles */}

<div className="absolute inset-0">

{[...Array(35)].map((_,i)=>(

<motion.div

key={i}

animate={{
y:[0,-15,0],
opacity:[0.2,0.6,0.2]
}}

transition={{
duration:2 + i%3,
repeat:Infinity
}}

className="absolute w-1 h-1 bg-white rounded-full"

style={{
top:Math.random()*100+"%",
left:Math.random()*100+"%"
}}

/>

))}

</div>

</div>

);

}