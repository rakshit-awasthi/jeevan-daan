import { useEffect, useState } from "react";
import { db } from "../services/firebase";
import { collection, getDocs } from "firebase/firestore";
import { Link } from "react-router-dom";
import Navbar from "../components/common/Navbar";
import { motion } from "framer-motion";

export default function FindDonor(){

const [users,setUsers]=useState([]);
const [search,setSearch]=useState("");
const [blood,setBlood]=useState("");

useEffect(()=>{

async function fetchUsers(){

const data = await getDocs(collection(db,"users"));

const list = data.docs.map(doc=>({

id:doc.id,
...doc.data()

}));

setUsers(list);

}

fetchUsers();

},[]);


const filteredUsers = users.filter(user=>

(
user.location?.toLowerCase().includes(search.toLowerCase()) ||
user.name?.toLowerCase().includes(search.toLowerCase())
)

&&

(blood ? user.bloodGroup===blood : true)

);


return(

<div className="min-h-screen text-white bg-gradient-to-br from-[#020617] via-[#020617] to-[#020617]">

<Navbar/>

{/* header */}

<div className="pt-28 text-center">

<h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-red-500 to-blue-500 bg-clip-text text-transparent">

Find Blood Donor

</h1>

<p className="text-gray-400 mt-3">

Search verified donors near you instantly

</p>

</div>


{/* search box */}

<div className="flex flex-col md:flex-row justify-center gap-4 mt-10 px-4">

<input
type="text"
placeholder="Search by city or name..."
value={search}
onChange={(e)=>setSearch(e.target.value)}
className="w-full md:w-[350px] p-3 rounded-xl bg-white/5 border border-white/10 backdrop-blur-lg focus:border-red-500 outline-none"
/>



<select
value={blood}
onChange={(e)=>setBlood(e.target.value)}
className="w-full md:w-[200px] p-3 rounded-xl bg-white/5 border border-white/10 backdrop-blur-lg focus:border-red-500 outline-none"
>

<option value="">All Blood Groups</option>

<option>A+</option>
<option>A-</option>
<option>B+</option>
<option>B-</option>
<option>O+</option>
<option>O-</option>
<option>AB+</option>
<option>AB-</option>

</select>

</div>



{/* donor cards */}

<div className="p-8 md:p-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">


{filteredUsers.length===0 && (

<p className="text-center col-span-3 text-gray-400">

No donors available

</p>

)}



{filteredUsers.map((user,i)=>(

<Link to={`/donor/${user.id}`} key={user.id}>

<motion.div

initial={{opacity:0,scale:0.9}}

animate={{opacity:1,scale:1}}

transition={{delay:i*0.05}}

whileHover={{y:-5}}

className="group relative p-[1px] rounded-2xl bg-gradient-to-r from-red-500 via-blue-500 to-red-500"

>


<div className="bg-[#020617] rounded-2xl p-6 backdrop-blur-xl border border-white/10 h-full">


<div className="flex items-center gap-4">


<img

src={

user.image ||

"https://cdn-icons-png.flaticon.com/512/149/149071.png"

}

className="w-16 h-16 rounded-full border border-white/20"

/>


<div>

<h2 className="text-lg font-semibold">

{user.name || "Unknown"}

</h2>


<p className="text-sm text-gray-400">

{user.location || "No location"}

</p>

</div>

</div>



<div className="mt-5 flex justify-between items-center">


<span className="text-xl font-bold text-red-500">

{user.bloodGroup || "--"}

</span>


<button className="text-sm bg-white/10 px-3 py-1 rounded-lg group-hover:bg-red-500 transition">

View

</button>


</div>


</div>


</motion.div>

</Link>

))}


</div>


</div>

);

}