import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Auth from "./pages/Auth";
import FindDonor from "./pages/finddonor";
import BecomeDonor from "./pages/becomedonor";
import RequestBlood from "./pages/RequestBlood";
import About from "./pages/About";
import DonorProfile from "./pages/DonorProfile";


import Profile from "./pages/Profile";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/profile" element={<Profile/>}/>
        <Route path="/find-donor" element={<FindDonor/>}/>
        <Route path="/become-donor" element={<BecomeDonor/>}/>
        <Route path="/about" element={<About/>} />
        <Route path="/request-blood" element={<RequestBlood/>} />
        <Route path="/donor/:id" element={<DonorProfile/>} />
        <Route path="/auth" element={<Auth />} />
        <Route path="/" element={<Home />} />
      </Routes>
    </BrowserRouter>
  );
}