export const healthData = {


// greetings
"hello":"Namaste 👋 kaise help kar sakta hoon?",
"hi":"Hello 🙂 health related question puch sakte ho.",
"namaste":"Namaste 🙏 mai health AI hoon.",
"good morning":"Good morning ☀️ healthy raho.",
"good evening":"Good evening 🙂 apna khayal rakho.",


// fever
"fever kya hai":"Fever body temperature badhne ko kehte hain.",
"fever ka ilaj":"Rest kare, pani piye aur paracetamol le sakte hain.",
"fever me kya kare":"Rest kare aur doctor se consult kare.",
"fever symptoms":"Body garam hona, weakness aur sweating.",
"viral fever treatment":"Rest aur fluids lena helpful hota hai.",


// cold
"cold kya hai":"Cold ek common viral infection hai.",
"cold ka ilaj":"Steam le aur garam pani piye.",
"jukham ka ilaj":"Steam aur rest helpful hota hai.",
"cold symptoms":"Nose band hona aur sneezing.",
"cold me kya kare":"Garam pani piye aur rest kare.",


// cough
"cough kya hai":"Cough throat irritation ki wajah se hota hai.",
"khansi ka ilaj":"Honey aur warm water le sakte hain.",
"dry cough treatment":"Steam aur honey helpful hota hai.",
"cough symptoms":"Gala kharab aur irritation.",
"khansi me kya kare":"Cold drink avoid kare.",


// headache
"headache kya hai":"Headache sar dard ko kehte hain.",
"sar dard ka ilaj":"Rest kare aur pani piye.",
"migraine kya hai":"Migraine severe headache hota hai.",
"migraine treatment":"Doctor ki advice le.",
"headache symptoms":"Sar me pressure aur pain.",


// stomach
"acidity kya hai":"Acidity stomach me acid badhne se hoti hai.",
"gas ka ilaj":"Light food khaye aur oily food avoid kare.",
"pet dard ka ilaj":"Rest kare aur doctor se consult kare.",
"constipation treatment":"Fiber rich food khaye.",
"diarrhea treatment":"ORS solution piye.",


// diabetes
"diabetes kya hai":"Diabetes me blood sugar high hoti hai.",
"diabetes ka ilaj":"Sugar control kare aur exercise kare.",
"sugar control kaise kare":"Healthy diet aur walk kare.",
"diabetes symptoms":"Thakan aur jyada pyaas lagna.",
"diabetes diet":"Low sugar diet follow kare.",


// bp
"bp kya hai":"BP blood pressure ko kehte hain.",
"high bp treatment":"Salt kam kare aur exercise kare.",
"low bp treatment":"Pani jyada piye.",
"bp symptoms":"Chakkar aur headache.",
"bp control kaise kare":"Healthy lifestyle follow kare.",


// heart
"heart pain kya kare":"Doctor se consult kare.",
"chest pain reason":"Chest pain heart ya muscle se ho sakta hai.",
"heart disease symptoms":"Chest pain aur breath problem.",
"heart healthy kaise rakhe":"Exercise kare aur junk food avoid kare.",
"heart attack symptoms":"Chest pain aur sweating.",


// mental health
"stress kya hai":"Stress mental pressure hota hai.",
"stress ka ilaj":"Yoga aur meditation kare.",
"anxiety kya hai":"Anxiety worry feeling hoti hai.",
"depression symptoms":"Sad feel hona aur interest kam hona.",
"mental health kaise improve kare":"Positive soch rakhe.",


// skin
"skin allergy kya hai":"Skin reaction ko allergy kehte hain.",
"skin care tips":"Face clean rakhe.",
"pimple treatment":"Face wash use kare.",
"dry skin treatment":"Moisturizer use kare.",
"itching ka ilaj":"Doctor se consult kare.",


// body pain
"body pain ka ilaj":"Rest kare aur stretch kare.",
"back pain treatment":"Exercise kare.",
"joint pain treatment":"Calcium rich food khaye.",
"neck pain treatment":"Correct posture rakhe.",
"leg pain treatment":"Massage helpful hota hai.",


// immunity
"immunity kaise badhaye":"Healthy diet aur fruits khaye.",
"vitamin c benefits":"Immunity strong karta hai.",
"exercise benefits":"Body fit rakhta hai.",
"sleep importance":"Sleep health ke liye zaruri hai.",
"water benefits":"Body hydrate rakhta hai.",


// general
"doctor kab dikhae":"Jab symptoms serious ho.",
"medicine kab le":"Doctor ki advice se.",
"healthy kaise rahe":"Daily exercise kare.",
"weight loss tips":"Healthy diet follow kare.",
"weight gain tips":"Protein diet le.",
"diet plan kya hai":"Balanced diet follow kare.",
"protein kya hai":"Protein body growth me help karta hai.",
"vitamin kya hai":"Vitamin body ke liye zaruri nutrient hai.",
"calcium benefits":"Bones strong banata hai.",
"iron benefits":"Blood healthy rakhta hai.",

// BLOOD DONATION 100 QUESTIONS

"blood donation kya hai":"Blood donation ek process hai jisme ek person apna blood donate karta hai dusre patient ki life save karne ke liye.",

"blood donate kaise kare":"Nearest blood bank ya hospital me jaakar blood donate kar sakte ho.",

"blood donation safe hai":"Haan blood donation completely safe hota hai.",

"blood donate karne se weakness hoti hai":"Temporary weakness ho sakti hai lekin body jaldi recover kar leti hai.",

"blood donation kitne time me hota hai":"Blood donation process 10-15 minute me complete ho jata hai.",

"blood donation age limit":"18 se 65 saal ke log blood donate kar sakte hain.",

"blood donate karne ke liye weight kitna hona chahiye":"Minimum 50kg weight hona chahiye.",

"blood donate kitni baar kar sakte hain":"3 mahine ke gap me blood donate kar sakte hain.",

"blood donate karne ke benefits":"Blood donation se kisi ki life save hoti hai aur health bhi improve hoti hai.",

"blood donation se kya fayda hota hai":"Blood donation heart health ke liye beneficial hota hai.",

"blood donation ke baad kya kare":"Juice piye aur rest kare.",

"blood donation ke baad kya nahi kare":"Heavy exercise avoid kare.",

"blood donate karne se infection hota hai":"Nahi sterile needle use hoti hai.",

"blood donation me kitna blood liya jata hai":"Approx 350-450 ml blood liya jata hai.",

"blood donation me kitna time lagta hai":"10 se 15 minute lagte hain.",

"blood donation ke baad kya khana chahiye":"Iron rich food khana chahiye.",

"blood donation ke baad dizziness":"Thodi dizziness normal hoti hai.",

"blood donate karne se weight kam hota hai":"Direct weight loss nahi hota.",

"blood donation heart ke liye acha hai":"Haan heart health ke liye beneficial hota hai.",

"blood donate karne se body clean hoti hai":"Body new blood cells banati hai.",

"blood donation kaun nahi kar sakta":"Pregnant women blood donate nahi kar sakti.",

"blood donation ke rules kya hai":"Healthy hona zaruri hai.",

"blood donation fasting me kar sakte hai":"Nahi fasting me donate nahi karna chahiye.",

"blood donation se kitni calories burn hoti hai":"Approx 600 calories burn hoti hain.",

"blood donation ke liye kya test hota hai":"Basic hemoglobin test hota hai.",

"blood donation ke baad pain hota hai":"Thoda pain normal hota hai.",

"blood donation harmful hai":"Nahi safe process hota hai.",

"blood donation se immunity badhti hai":"Indirectly health improve hoti hai.",

"blood donation ke baad kitna rest kare":"Kam se kam 30 minute rest kare.",

"blood donation ke baad driving kar sakte hai":"Haan thoda rest ke baad kar sakte hain.",

"blood donation ke baad gym kar sakte hai":"Same din gym avoid kare.",

"blood donation ke baad smoking kar sakte hai":"Smoking avoid kare.",

"blood donation ke baad alcohol":"Alcohol avoid kare.",

"blood donation kitne interval me kare":"3 month interval me kare.",

"blood donation se hemoglobin kam hota hai":"Temporary kam hota hai fir normal ho jata hai.",

"blood donation ke liye hemoglobin kitna hona chahiye":"Minimum 12.5 hona chahiye.",

"blood donation ke liye health condition":"Healthy person donate kar sakta hai.",

"blood donation ka process":"Registration, test aur blood collection hota hai.",

"blood donation ke baad juice kyu dete hai":"Energy maintain karne ke liye.",

"blood donation ke baad weakness":"Temporary weakness normal hoti hai.",

"blood donation ke baad exercise kab kare":"24 ghante baad kare.",

"blood donation ke liye id proof chahiye":"Haan id proof helpful hota hai.",

"blood donation me pain hota hai":"Thoda needle pain hota hai.",

"blood donation ke baad pani kitna piye":"Zyada pani piye.",

"blood donation ke baad kya avoid kare":"Heavy lifting avoid kare.",

"blood donation ke baad kitna sleep kare":"Proper sleep le.",

"blood donation safe kyu hai":"Sterile equipment use hota hai.",

"blood donation ke liye appointment":"Online appointment le sakte ho.",

"blood donation kaha kare":"Hospital ya blood bank me kare.",

"blood donation camp kya hota hai":"Temporary blood collection event hota hai.",

"blood donation me kya documents chahiye":"Basic id proof.",

"blood donation free hota hai":"Haan free hota hai.",

"blood donation voluntary hota hai":"Haan voluntary hota hai.",

"blood donation emergency me help karta hai":"Emergency me life save karta hai.",

"blood donation life save karta hai":"Ek donation 3 life save kar sakta hai.",

"blood donation ke liye kya khaye":"Healthy food khaye.",

"blood donation ke baad fruits khaye":"Haan fruits helpful hote hain.",

"blood donation ke baad milk piye":"Milk pi sakte hain.",

"blood donation ke baad chai":"Chai avoid kare turant.",

"blood donation ke baad coffee":"Coffee kam piye.",

"blood donation ke baad dizziness kyu hoti hai":"Blood volume temporary kam hota hai.",

"blood donation ke baad kya symptoms normal hai":"Thodi weakness normal hai.",

"blood donation ke liye age proof":"Age verify hoti hai.",

"blood donation ke liye fitness":"Fit hona zaruri hai.",

"blood donation ke liye medical checkup":"Basic checkup hota hai.",

"blood donation me kitna blood safe hai":"450 ml safe hota hai.",

"blood donation ke baad kya feel hota hai":"Thoda light feel ho sakta hai.",

"blood donation ke baad hydration":"Hydration maintain kare.",

"blood donation me needle safe hoti hai":"Haan new needle use hoti hai.",

"blood donation ke liye registration":"Online ya offline kar sakte ho.",

"blood donation ke liye hospital":"Hospital me donate kare.",

"blood donation ke baad kitna gap":"3 month gap.",

"blood donation ke liye eligibility":"Healthy adult eligible hota hai.",

"blood donation ke baad health effect":"Positive effect hota hai.",

"blood donation ke liye doctor advice":"Doctor se consult kar sakte ho.",

"blood donation ke baad rest important":"Rest zaruri hota hai.",

"blood donation ke baad energy kam":"Temporary kam hoti hai.",

"blood donation ke liye gender limit":"Male aur female dono donate kar sakte hain.",

"blood donation ke liye pregnancy rule":"Pregnant women donate nahi kar sakti.",

"blood donation ke liye medicine rule":"Kuch medicine lene par donate nahi kar sakte.",

"blood donation ke baad kitna pani":"2-3 glass pani piye.",

"blood donation ke baad juice":"Juice helpful hota hai.",

"blood donation ke baad sugar level":"Sugar normal rehta hai.",

"blood donation ke baad headache":"Kabhi kabhi mild headache hota hai.",

"blood donation ke baad recovery":"Body jaldi recover karti hai.",

"blood donation ke baad kya normal hai":"Thodi weakness normal hai.",

"blood donation ke liye healthy lifestyle":"Healthy lifestyle follow kare.",

"blood donation ka importance":"Blood donation life saving hai.",

"blood donation ka objective":"Patients ko blood provide karna.",

"blood donation social help hai":"Society ke liye helpful hai.",

"blood donation humanity ke liye acha hai":"Humanity help hoti hai.",

"blood donation awareness kyu zaruri hai":"Logon ko educate karne ke liye.",

"blood donation motivate kaise kare":"Logon ko awareness de.",

"blood donation ke liye campaign":"Blood donation camp organize kare.",

"blood donation emergency help":"Emergency me zaruri hota hai.",

"blood donation community help":"Community ko support milta hai.",

"blood donation ek good habit":"Good habit hai.",

"blood donation ek noble cause":"Noble cause hai.",

"blood donation ek social work":"Social work hai."

};