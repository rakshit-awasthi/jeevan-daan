import { healthData } from "./healthData";


// basic conversation
const basicData={

hello:[
"Namaste 👋 kaise help kar sakta hoon?",
"Hello! aap health related question puch sakte ho.",
"Hi 😊 mai health AI hoon."
],

thanks:[
"Aapka welcome 🙂",
"Koi baat nahi 👍",
"Khushi hui help karke"
],

bye:[
"Bye 👋 apna khayal rakhna",
"Fir milte hain 🙂",
"Healthy raho"
]

};


// memory
function loadMemory(){

return JSON.parse(
localStorage.getItem("ai_memory")||"{}"
);

}

function saveMemory(data){

localStorage.setItem(
"ai_memory",
JSON.stringify(data)
);

}


// find keyword
function findHealthAnswer(text){

text=text.toLowerCase();

for(const key in healthData){

if(text.includes(key.split(" ")[1])){

return healthData[key];

}

}

return null;

}


// main AI
export function AIResponse(question){

const q=question.toLowerCase();

const memory=loadMemory();


// learned
if(memory[q]){

return memory[q];

}


// basic talk
if(q.match(/hello|hi|namaste|hey/)){

return random(basicData.hello);

}

if(q.match(/thank/)){

return random(basicData.thanks);

}

if(q.match(/bye|goodbye/)){

return random(basicData.bye);

}


// health search
const healthAnswer=findHealthAnswer(q);

if(healthAnswer){

return healthAnswer;

}


// fallback
return "Mujhe iska exact answer nahi mila, doctor se consult karna better rahega.";

}


function random(arr){

return arr[Math.floor(Math.random()*arr.length)];

}