import { Link, useLocation, useNavigate } from "react-router-dom";

import { useState, useEffect } from "react";

import { motion, AnimatePresence } from "framer-motion";

import { auth } from "../../services/firebase";

import { onAuthStateChanged, signOut } from "firebase/auth";

export default function Navbar(){

const [isOpen,setIsOpen] = useState(false);

const [user,setUser] = useState(null);

const location = useLocation();

const navigate = useNavigate();



useEffect(()=>{

const unsubscribe = onAuthStateChanged(auth,(u)=>{

setUser(u);

});

return ()=>unsubscribe();

},[]);



async function logout(){

await signOut(auth);

navigate("/");

}



const navLink =

"relative px-2 py-1 hover:text-blue-400 transition";



const activeLink =

"text-blue-400 font-semibold after:absolute after:left-0 after:-bottom-1 after:w-full after:h-[2px] after:bg-blue-400";



return(

<motion.nav

initial={{y:-80}}

animate={{y:0}}

transition={{duration:0.5}}

className="fixed w-full top-0 z-50 backdrop-blur-xl bg-black/20 border-b border-white/10"

>

<div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center text-white">


<Link to="/" className="text-2xl font-bold text-blue-400">

JIVAN DAAN

</Link>



<div className="hidden md:flex gap-8 items-center">


<Link to="/" className={`${navLink} ${location.pathname==="/" ? activeLink : ""}`}>

Home

</Link>



<Link to="/find-donor" className={`${navLink} ${location.pathname==="/find-donor" ? activeLink : ""}`}>

Find Donor

</Link>
<Link to="/become-donor">
Become Donor
</Link>



<Link to="/request-blood">Request Blood</Link>



<Link to="/about" className={`${navLink} ${location.pathname==="/about" ? activeLink : ""}`}>

About

</Link>



<Link to="/profile" className={`${navLink} ${location.pathname==="/profile" ? activeLink : ""}`}>

Profile

</Link>



{user ?(

<button

onClick={logout}

className="bg-red-600 px-5 py-2 rounded-xl hover:bg-red-700"

>

Logout

</button>

):(

<Link

to="/auth"

className="bg-blue-600 px-5 py-2 rounded-xl hover:bg-blue-700"

>

Login

</Link>

)}


</div>



<button

onClick={()=>setIsOpen(!isOpen)}

className="md:hidden text-2xl"

>

☰

</button>


</div>



<AnimatePresence>

{isOpen &&(

<motion.div

initial={{opacity:0,y:-20}}

animate={{opacity:1,y:0}}

exit={{opacity:0}}

className="md:hidden bg-black/90 px-6 py-6 space-y-4 text-white"

>


<Link to="/">Home</Link>

<Link to="/find">Find Donor</Link>

<Link to="/request">Request Blood</Link>

<Link to="/about">About</Link>

<Link to="/profile">Profile</Link>



{user ?(

<button

onClick={logout}

className="block bg-red-600 px-4 py-2 rounded-lg w-full"

>

Logout

</button>

):(

<Link

to="/auth"

className="block bg-blue-600 px-4 py-2 rounded-lg text-center"

>

Login

</Link>

)}


</motion.div>

)}

</AnimatePresence>


</motion.nav>

);

}