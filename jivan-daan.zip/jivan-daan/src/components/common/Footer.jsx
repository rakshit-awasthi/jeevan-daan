export default function Footer() {
  return (
    <div className="mt-28 border-t border-white/10 bg-black text-white">
      <div className="max-w-6xl mx-auto px-6 py-10 text-center">

        <h2 className="text-2xl font-bold text-blue-500">
          JIVAN DAAN
        </h2>

        <p className="text-gray-400 mt-3">
          Saving lives through technology ❤️
        </p>

        <div className="mt-6 text-sm text-gray-500">
          © {new Date().getFullYear()} JIVAN DAAN
        </div>

      </div>
    </div>
  );
}