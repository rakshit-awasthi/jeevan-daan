import { useState } from "react";
import { motion } from "framer-motion";

export default function FindDonor(){

const [search,setSearch]=useState("");
const [blood,setBlood]=useState("");

const donors = [
{
id:1,
name:"Rahul Sharma",
blood:"A+",
city:"Lucknow",
contact:"9876543210"
},
{
id:2,
name:"Priya Singh",
blood:"B+",
city:"Kanpur",
contact:"9123456780"
},
{
id:3,
name:"Amit Verma",
blood:"O+",
city:"Delhi",
contact:"9988776655"
},
{
id:4,
name:"Neha Gupta",
blood:"AB+",
city:"Lucknow",
contact:"9090909090"
},
{
id:5,
name:"Rohit Yadav",
blood:"O-",
city:"Varanasi",
contact:"8888888888"
}
];

const filteredDonors = donors.filter(donor =>
(donor.name.toLowerCase().includes(search.toLowerCase()) ||
 donor.city.toLowerCase().includes(search.toLowerCase()))
&&
(blood ? donor.blood===blood : true)
);

return(

<div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white p-6">

<h1 className="text-3xl font-bold mb-6 text-center">
Find Blood Donor
</h1>

{/* Search */}
<div className="flex flex-col md:flex-row gap-4 justify-center mb-8">

<input
type="text"
placeholder="Search by name or city..."
value={search}
onChange={(e)=>setSearch(e.target.value)}
className="px-4 py-2 rounded-xl bg-black border border-gray-700 focus:border-red-500 outline-none w-full md:w-1/3"
/>

<select
value={blood}
onChange={(e)=>setBlood(e.target.value)}
className="px-4 py-2 rounded-xl bg-black border border-gray-700 focus:border-red-500 outline-none w-full md:w-1/4"
>

<option value="">All Blood Groups</option>
<option>A+</option>
<option>A-</option>
<option>B+</option>
<option>B-</option>
<option>AB+</option>
<option>AB-</option>
<option>O+</option>
<option>O-</option>

</select>

</div>

{/* Donor Cards */}

<div className="grid md:grid-cols-3 gap-6">

{filteredDonors.map(donor=>(

<motion.div
key={donor.id}
whileHover={{scale:1.05}}
className="bg-gray-900 border border-gray-800 p-5 rounded-2xl shadow-lg"
>

<h2 className="text-xl font-semibold mb-2">
{donor.name}
</h2>

<p className="text-red-400 font-bold">
Blood: {donor.blood}
</p>

<p className="text-gray-400">
City: {donor.city}
</p>

<p className="text-gray-400 mb-3">
Contact: {donor.contact}
</p>

<button className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-xl w-full">
Request Blood
</button>

</motion.div>

))}

</div>

</div>

);
}