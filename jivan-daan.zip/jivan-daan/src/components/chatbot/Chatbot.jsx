import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { AIResponse } from "../../ai/brain";

export default function AIChatbot(){

const [open,setOpen]=useState(false);

const [messages,setMessages]=useState([
{
role:"assistant",
content:"Namaste 👋 mai Health AI hoon."
}
]);

const [input,setInput]=useState("");

const [typing,setTyping]=useState(false);
const [listening,setListening]=useState(false);
const [speaking,setSpeaking]=useState(false);
const [liveText,setLiveText]=useState("");

const recognitionRef = useRef(null);
const chatRef = useRef(null);
const voicesRef = useRef([]);


// scroll
useEffect(()=>{

chatRef.current?.scrollTo({

top: chatRef.current.scrollHeight,
behavior:"smooth"

});

},[messages]);



// voices
useEffect(()=>{

voicesRef.current=speechSynthesis.getVoices();

speechSynthesis.onvoiceschanged=()=>{

voicesRef.current=speechSynthesis.getVoices();

};

},[]);



// speech recognition
useEffect(()=>{

const SpeechRecognition=
window.SpeechRecognition||
window.webkitSpeechRecognition;

if(!SpeechRecognition) return;

const recognition=new SpeechRecognition();

recognition.lang="hi-IN";

recognition.continuous=true;

recognition.interimResults=true;


recognition.onstart=()=>{

setListening(true);

setLiveText("");

};


recognition.onresult=(event)=>{

let text="";

for(let i=event.resultIndex;i<event.results.length;i++){

text+=event.results[i][0].transcript;

}

setLiveText(text);

setInput(text);

};


recognition.onend=()=>{

setListening(false);

if(liveText){

sendMessage(liveText);

setLiveText("");

}

};


recognitionRef.current=recognition;

},[liveText]);



// speak
function speak(text){

const utter=new SpeechSynthesisUtterance(text);

const voice=
voicesRef.current.find(v=>v.lang==="hi-IN")||
voicesRef.current.find(v=>v.lang.includes("hi"));

if(voice) utter.voice=voice;

utter.lang="hi-IN";

speechSynthesis.cancel();

speechSynthesis.speak(utter);

}



// send
function sendMessage(customText){

const msg=customText||input;

if(!msg.trim()) return;


setMessages(prev=>[
...prev,
{role:"user",content:msg}
]);


setInput("");

setTyping(true);


setTimeout(()=>{

const reply=AIResponse(msg);


setMessages(prev=>[
...prev,
{role:"assistant",content:reply}
]);


setTyping(false);

speak(reply);


},400);

}



// mic
function toggleMic(){

if(!recognitionRef.current) return;


if(listening){

recognitionRef.current.stop();

}else{

recognitionRef.current.start();

}

}



return(

<>

<motion.button
onClick={()=>setOpen(!open)}
className="fixed bottom-6 right-6 bg-red-600 w-14 h-14 rounded-full text-white"
>
AI
</motion.button>



<AnimatePresence>

{open&&(

<motion.div
initial={{opacity:0}}
animate={{opacity:1}}
className="fixed bottom-24 right-6 w-80 h-[520px] bg-black border border-red-500 rounded-xl flex flex-col"
>


<div className="bg-red-600 p-2 text-white text-center">

Health AI 🧠

</div>



<div
ref={chatRef}
className="flex-1 overflow-y-auto p-3 text-white"
>


{messages.map((m,i)=>(

<div key={i}>

<b>{m.role==="user"?"You":"AI"}:</b>

{m.content}

</div>

))}


{typing&&<p>AI typing...</p>}


{listening&&(

<p className="text-green-400">

Listening 🎤 {liveText}

</p>

)}


{speaking&&(

<p className="text-blue-400">

Speaking 🔊

</p>

)}

</div>



<div className="flex">


<input
value={input}
onChange={e=>setInput(e.target.value)}
className="flex-1 p-2 bg-black text-white"
/>



<button
onClick={()=>sendMessage()}
className="bg-red-600 px-3"
>
Send
</button>



<button
onClick={toggleMic}
className="bg-green-600 px-3"
>
🎤
</button>


</div>


</motion.div>

)}

</AnimatePresence>


</>

);

}