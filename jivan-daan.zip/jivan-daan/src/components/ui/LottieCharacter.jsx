import { useEffect, useRef } from "react";
import lottie from "lottie-web";
import anim1 from "../../assets/happy.json";
import anim2 from "../../assets/happy.json";
import anim3 from "../../assets/happy.json";

export default function LottieCharacter() {

  const c1 = useRef(null);
  const c2 = useRef(null);
  const c3 = useRef(null);

  useEffect(() => {

    const a1 = lottie.loadAnimation({
      container: c1.current,
      renderer: "svg",
      loop: true,
      autoplay: true,
      animationData: anim1
    });

    const a2 = lottie.loadAnimation({
      container: c2.current,
      renderer: "svg",
      loop: true,
      autoplay: true,
      animationData: anim2
    });

    const a3 = lottie.loadAnimation({
      container: c3.current,
      renderer: "svg",
      loop: true,
      autoplay: true,
      animationData: anim3
    });

    const move = (e) => {

      const x = e.clientX / window.innerWidth - 0.5;
      const y = e.clientY / window.innerHeight - 0.5;

      c1.current.style.transform =
        `translate(${x * 20}px, ${y * 20}px)`;

      c2.current.style.transform =
        `translate(${x * -30}px, ${y * 15}px)`;

      c3.current.style.transform =
        `translate(${x * 15}px, ${y * -25}px)`;
    };

    window.addEventListener("mousemove", move);

    return () => {
      a1.destroy();
      a2.destroy();
      a3.destroy();
      window.removeEventListener("mousemove", move);
    };

  }, []);

  return (

    <div className="relative flex items-center justify-center">

      <div
        ref={c1}
        className="w-[220px] h-[220px] z-20"
      />

      <div
        ref={c2}
        className="w-[160px] h-[160px] absolute left-[-120px] top-[40px] opacity-70"
      />

      <div
        ref={c3}
        className="w-[140px] h-[140px] absolute right-[-120px] top-[60px] opacity-60"
      />

    </div>

  );
}