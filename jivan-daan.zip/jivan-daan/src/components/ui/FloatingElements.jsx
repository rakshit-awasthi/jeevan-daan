import { useState } from "react";

export default function FloatingElements({ isHappy }) {
  const [clicked, setClicked] = useState(false);

  let emoji = "";

  if (isHappy) {
    emoji = "";
  } else if (clicked) {
    emoji = "";
  }

  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0">

      {/* EMOJI CHARACTER */}
      <div
        onClick={() => setClicked(true)}
        className="text-8xl cursor-pointer pointer-events-auto transition transform hover:scale-110"
      >
        {emoji}
      </div>

    </div>
  );
}