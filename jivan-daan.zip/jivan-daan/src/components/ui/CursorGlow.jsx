import { useEffect, useState } from "react";

export default function CursorGlow() {
  const [pos, setPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const move = (e) => {
      setPos({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener("mousemove", move);
    return () => window.removeEventListener("mousemove", move);
  }, []);

  return (
    <div
      className="pointer-events-none fixed top-0 left-0 z-[9999]"
      style={{
        transform: `translate(${pos.x - 75}px, ${pos.y - 75}px)`
      }}
    >
      {/* INNER DOT */}
      <div className="w-[20px] h-[20px] bg-blue-400 rounded-full"></div>

      {/* OUTER GLOW */}
      <div className="absolute top-[-50px] left-[-50px] w-[120px] h-[120px] bg-blue-500 opacity-30 rounded-full blur-2xl"></div>
    </div>
  );
}